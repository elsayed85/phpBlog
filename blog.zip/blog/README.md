### Installation

#### Create DB "blog"

#### import sql file from /Database folder

#### Run composer install to dump all helpers

#### Go To localhost/index.php 