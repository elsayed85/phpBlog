<?php

return [
    'title' => "BLOG"
];