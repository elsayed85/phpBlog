<?php

return [
    'post/{id:\d+}' => [
        'controller' => 'main',
        'action' => 'post',
    ],
];